function cmap = RWB2cmap(cmin, cmax)

% W0cmap                           custom colormap with white centered at 0
%==========================================================================
% 
% USAGE:  
%  cmap = W0cmap(cmin, cmax, colorneg, colorpos)
%
% DESCRIPTION:
%  Creates a custom colormap that spans the range from cmin to cmax, where 
%  white is assigned to the value zero.  Your choice of colormax is assigned 
%  to positive numbers; your choice of colormin is assigned to negative 
%  numbers.  This colormap is most useful for showing departures in some 
%  quantity from zero. The zero value need not be between cmin and cmax.
%
% INPUT:
%  cmin = minimum value for colormap
%  cmax = maximum value for colormap
%  colorneg = RGB triplet for neg. color on cmap scale (e.g. [0 0 1] = blue)
%  colorpos = RGB triplet for pos. color on cmap scale (e.g. [1 0 0] = red)
%
% OUTPUT:
%  cmap = matrix of colors for the colormap.  Type "colormap(cmap)" to use,
%       after the data is plotted.
%  
%  Joanna Young - January 30, 2012 
%  and
%  Tim Bartholomaus (author of RWBcmap.m, on which this code is based) - Nov. 28, 2011
%  
%

range = cmax - cmin;

keep_portion = range / (2* max(abs([cmax, cmin]))); % ranges between 0 and 1

j = 2*size(colormap, 1);
n = fix(0.5*j);
% rpos = colorpos(1); gpos = colorpos(2); bpos = colorpos(3);
% rneg = colorneg(1); gneg = colorneg(2); bneg = colorneg(3);
% 
% r = [rpos + (0:1:n-1)/n*(1-rpos), 1 - (0:1:n-1)/n*(1-rneg)]; 
% g = [gpos + (0:1:n-1)/n*(1-gpos), 1 - (0:1:n-1)/n*(1-gneg)];
% b = [bpos + (0:1:n-1)/n*(1-bpos), 1 - (0:1:n-1)/n*(1-bneg)];
% cmap = flipud([r(:), g(:), b(:)]);
cmap = abs(cbrewer('div','RdBu',128));
cmap(cmap>1)=1; 

cut_out = round((1-keep_portion)*(j-1)); % ranges between 0 and j-1

if abs(cmax) >= abs(cmin)
    cmap = cmap(cut_out+1 : end, :);
else
    cmap = cmap(1 : end-cut_out, :);
end

% The resulting matrix, cmap, is the colormap
