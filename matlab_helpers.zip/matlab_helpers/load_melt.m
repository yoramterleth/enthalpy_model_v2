%% load melt data 
function [Atime, taxis_plot] =load_melt(times) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% USER SPECIFICATIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
outdir = 'E:/OutputTURNER_25052022/' ;%['D:/OutputTURNER_31122021/'] ; %['K:/melt_model/EBFM_outputs/Output_11_08_2021/'];% '..\Output\';                  % output directory
coords =  [577993 6654010] ; %[566224 6663430];%[572336 6657710]  [566653 6661670] %[570014 6659000 ]% %    [566653 6661670]; % % location (UTM) 
timeseries_start = '1-Aug-2020 00:00'; % start date
timeseries_end = '10-Oct-2021 00:00';   % start time
var = 'runoff';                           % plot variable (choose from list 
                                        % 	in io.varsout)
                                        
normalise_data = 'none'  ;              % 'sqrt' or 'log10' or [] for no norm                                      
                                        
smooth_melt = 1 ; 
wl = 3; % movmean windowlength for plotting

timeseries_start = times(1) ; % datetime(timeseries_start) ; % datetime(2021,06,01); 
timeseries_end = times(2) ; % datetime(timeseries_end) ; % datetime(2021,08,15);

%% load melt series 

load([outdir '\runinfo.mat']);

ind = find(strcmp(var,{IOout.varsout.varname}));

L = length(grid.mask);
time_start = time.ts;
time_end = time.te;
period = IOout.freqout*time.dt;
tvec = datenum(time_start):period:datenum(time_end);
T = (datenum(time_end) - datenum(time_start))/period;

diff_y = grid.y(:)-coords(2);
diff_x = grid.x(:)-coords(1);
diff = sqrt(diff_y.^2 + diff_x.^2);
gp = find(diff == min(diff));

varabr = IOout.varsout(ind).varname;
varname = IOout.varsout(ind).description;
units = IOout.varsout(ind).units;
type = IOout.varsout(ind).type;

taxis = datetime(datevec(datenum(timeseries_start):IOout.freqout*...
    time.dt:datenum(timeseries_end)+0.5*IOout.freqout*time.dt));
tind = [];
taxis_plot_datenum = [];
for tt=1:length(taxis)
    if min(abs(datenum(IOout.output_times)-datenum(taxis(tt))))<...
            IOout.freqout*time.dt
        [~,tind(end+1)] = min(abs(datenum(IOout.output_times)-...
            datenum(taxis(tt))));
        taxis_plot_datenum(end+1) = datenum(IOout.output_times(tind(end)));
    end
end
taxis_plot = datetime(datevec(taxis_plot_datenum));

Atime = [];

fid = fopen([outdir '/OUT_' varabr '.bin'],'rb');
count = 0;
for t=1:length(tind)
    fseek(fid,(tind(t)-1)*4*L+(gp-1)*4,'bof');
    Atemp = fread(fid,1,'real*4','l');
    Atime(end+1) = Atemp;
end
fclose(fid);

if smooth_melt
    Atime = movmean(Atime,wl); 
end 

end 

