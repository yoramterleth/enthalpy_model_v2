%% seismic power colormap

%% 
close all
clear all
clc

%% info 
s_time = datetime(2020,09,30); 
e_time = datetime(2021,08,01);

%% load data 
load GHT_output.mat

stations = a{1,1} ; 
freq_range = a{1,2} ; 

% times
steps = length(stations.SE7.t); 
TIME = linspace(s_time,e_time,steps); 
fns = fieldnames(stations);
fns = {'SW2','SE7','SW7','SW8','SE9' ,'SE14','SW14','SE15'}; 
time = datetime(stations.SE7.t,'ConvertFrom','posixtime'); % hours(stations.SE7.t(1))+ datetime(1970,01,01)


%% make array 
matrix = []; %zeros(length(time),length(fns)); 

for i = 1:length(fns)
    t = datetime(stations.(subsref(fns,substruct('{}',{i}))).t,'ConvertFrom','posixtime');
    cur_col = stations.(subsref(fns,substruct('{}',{i}))).powdB';
    cur_col = cur_col(t>s_time & t<e_time);
    norm_cur_col = cur_col - nanmean(cur_col(:)); 
    
    %if length(matrix(:,1)) == length(norm_cur_col)
    matrix = [matrix,norm_cur_col];
    %else print([fns(i) 'not correct length'])
end 

 t_plot = t(t>s_time & t<e_time); 

%% plot figure
figure
pcolor([1:length(fns)], t_plot, matrix)
shading flat
xticklabels(fns)
axis ij
set(gca,'xaxisLocation','top')
cmap = abs(cbrewer('div','RdBu',128));
cmap(cmap>1)=1; 
colormap(cmap)
caxis([-max(abs(matrix(:))), max(abs(matrix(:)))]); 
c = colorbar ; 
ylabel(c,'power deviation from mean at timestep [dB]')
  
